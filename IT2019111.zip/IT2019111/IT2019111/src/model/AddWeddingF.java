/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Statement;

/**
 *
 * @author Shashi
 */
public class AddWeddingF {
    
      Statement stmt;
    
    public void WeddingF(String sname, String fname, String email, String pnumber, String address, String country, String day, String month, String year, String attendees, String guestrooms, String request){
        
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("INSERT INTO wedding VALUES ('"+sname+"', '"+fname+"', '"+email+"', '"+pnumber+"', '"+address+"', '"+country+"', '"+day+"', '"+month+"', '"+year+"', '"+attendees+"', '"+guestrooms+"',  '"+request+"' )");
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
}





    
        
        
  