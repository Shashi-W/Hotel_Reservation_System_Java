/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.Statement;

/*DBSearch
 *
 * @author Shashi
 */
public class DBSearch {
    Statement stmt;
    private ResultSet rs;
    
   public ResultSet searchLogin(String usName){
        try{
             stmt = DBConnection.getStatementConnection();
            String name = usName;
            
            
            //Execute the query
            rs = stmt.executeQuery("SELECT * FROM login WHERE username='" + name + "'" );
        }catch (Exception e){
            e.printStackTrace();
            
        }
        return rs;
    }
   
   public ResultSet WeddingF(){  // method name
       
       try{
           
           stmt = DBConnection.getStatementConnection();
           rs = stmt.executeQuery("SELECT * FROM wedding ");          
           
       }catch(Exception e){
           e.printStackTrace();
       }
       return rs;
   }
   
   
   public ResultSet WeddingDisplay(){  // method name
       
       try{
           
           stmt = DBConnection.getStatementConnection();
           rs = stmt.executeQuery("SELECT * FROM wedding ");          
           
       }catch(Exception e){
           e.printStackTrace();
       }
       return rs;
   }
   
     public ResultSet RoyalRoomDisplay(){  // method name
       
       try{
           
           stmt = DBConnection.getStatementConnection();
           rs = stmt.executeQuery("SELECT * FROM royal ");          
           
       }catch(Exception e){
           e.printStackTrace();
       }
       return rs;
   }
    
     
       public ResultSet OceanViewDisplay(){  // method name
       
       try{
           
           stmt = DBConnection.getStatementConnection();
           rs = stmt.executeQuery("SELECT * FROM ocean_view ");          
           
       }catch(Exception e){
           e.printStackTrace();
       }
       return rs;
   }
       
           public ResultSet Feedback(){  // method name
       
       try{
           
           stmt = DBConnection.getStatementConnection();
           rs = stmt.executeQuery("SELECT * FROM feedback ");          
           
       }catch(Exception e){
           e.printStackTrace();
       }
       return rs;
   }
     
}
