/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Statement;

/**
 *
 * @author Shashi
 */
public class AddFeedback {
    
      Statement stmt;
    
    public void Feedback(String name,  String email, String subject, String message ){
        
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("INSERT INTO feedback VALUES ('"+name+"',  '"+email+"', '"+subject+"', '"+message+"'  )");
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
}
