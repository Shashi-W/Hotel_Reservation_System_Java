/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Statement;

/**
 *
 * @author Shashi
 */
public class AddRoyal {
    
      Statement stmt;
    
    public void RoyalRoom(String nameTF, String nicTF, String emailTF, String roomTF, String dateTF, String dateDTF){
        
        try{
            stmt = DBConnection.getStatementConnection();
            stmt.executeUpdate("INSERT INTO royal VALUES ('"+nameTF+"', '"+nicTF+"', '"+emailTF+"', '"+roomTF+"', '"+dateTF+"', '"+dateDTF+"' )");
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
}
