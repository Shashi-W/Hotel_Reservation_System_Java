/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Shashi
 */
public class FeedbackController {
    
       public static void Feedback(String name, String email, String subject, String message){
        
        new model.AddFeedback().Feedback(name, email, subject, message);
        
        JOptionPane.showMessageDialog(null, "Thank You...", " ", JOptionPane.INFORMATION_MESSAGE);
        
    
    }
}
