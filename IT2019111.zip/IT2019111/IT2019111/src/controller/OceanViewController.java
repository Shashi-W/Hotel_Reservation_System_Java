/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Shashi
 */
public class OceanViewController {
    
    public static void OceanViewRoom(String nameTF, String nicTF, String roomTF, String dateTF, String dateDTF){
        
        new model.AddOceanView().OceanViewRoom(nameTF, nicTF, roomTF, dateTF, dateDTF);
        
        JOptionPane.showMessageDialog(null, "Your Booking Successfull. Thank You...", "", JOptionPane.INFORMATION_MESSAGE);
        
    
    }
    
}
