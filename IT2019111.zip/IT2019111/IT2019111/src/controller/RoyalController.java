/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Shashi
 */
public class RoyalController {
    
     public static void RoyalRoom(String nameTF, String nicTF, String emailTF, String roomTF, String dateTF, String dateDTF){
        
        new model.AddRoyal().RoyalRoom(nameTF, nicTF, emailTF, roomTF, dateTF, dateDTF);
        
        JOptionPane.showMessageDialog(null, "Your Booking Successfull. Thank You...", "", JOptionPane.INFORMATION_MESSAGE);
        
    
    }
    
}
