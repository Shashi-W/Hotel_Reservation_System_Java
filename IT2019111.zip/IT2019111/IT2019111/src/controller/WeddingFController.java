/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import javax.swing.JOptionPane;

/**
 *
 * @author Shashi
 */
public class WeddingFController {
    
      public static void WeddingF(String sname, String fname, String email, String pnumber, String address, String country, String day, String month, String year, String attendees, String guestrooms, String request){
        
        new model.AddWeddingF().WeddingF(sname, fname, email,  pnumber,   address,  country,  day,  month, year,  attendees,  guestrooms,  request);
        
        JOptionPane.showMessageDialog(null, "Your Booking Successfull. Thank You...", "", JOptionPane.INFORMATION_MESSAGE);
        
    
    }

  
}
