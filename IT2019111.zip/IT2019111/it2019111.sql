-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 01, 2021 at 04:39 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `it2019111`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `subject`, `message`) VALUES
('shashi', 'shashi@gmail.com', 'exam', 'final project'),
('ada', 'adawd', 'adaw', 'dawda'),
('wijendra', 'wijendra@gmail.com', 'n nn', 'bdkmm'),
('Danu', 'danu@gmail.com', 'feedback', 'great'),
('Danu', 'danu@gmail.com', 'feedback', 'great'),
('', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'shashi', '12345'),
(2, 'wijendra', '111111');

-- --------------------------------------------------------

--
-- Table structure for table `ocean_view`
--

DROP TABLE IF EXISTS `ocean_view`;
CREATE TABLE IF NOT EXISTS `ocean_view` (
  `nameTF` varchar(50) NOT NULL,
  `nicTF` varchar(50) NOT NULL,
  `roomTF` int(11) NOT NULL,
  `dateTF` varchar(50) NOT NULL,
  `dateDTF` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ocean_view`
--

INSERT INTO `ocean_view` (`nameTF`, `nicTF`, `roomTF`, `dateTF`, `dateDTF`) VALUES
('shashi', '23456v', 1, '27.05.2021', '28.05.2021'),
('df', '345', 1, '1.1.2021', '2.1.2021'),
('Nimmi', '7865935v', 2, '4.06.2021', '06.06.2021'),
('Nimmi', '7865935v', 2, '4.06.2021', '06.06.2021'),
('Ganesh', '9808654v', 1, '08.08.2021', '09.08.2021'),
('Chanu', '456784v', 1, '3.05.2021', '4.05.2021'),
('kavidu', '123456v', 1, '02.06.2021', '04.06.2021');

-- --------------------------------------------------------

--
-- Table structure for table `royal`
--

DROP TABLE IF EXISTS `royal`;
CREATE TABLE IF NOT EXISTS `royal` (
  `nameTF` varchar(50) NOT NULL,
  `nicTF` varchar(50) NOT NULL,
  `emailTF` varchar(50) NOT NULL,
  `roomTF` varchar(50) NOT NULL,
  `dateTF` varchar(50) NOT NULL,
  `dateDTF` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `royal`
--

INSERT INTO `royal` (`nameTF`, `nicTF`, `emailTF`, `roomTF`, `dateTF`, `dateDTF`) VALUES
('shashi', '8754v', 'shashi@gmail.com', '1', '12.04.2021', '13.04.2021'),
('Shashi', '23456v', 'Shshi@gmail.com', '2', '04.05.2021', '06.05.2021'),
('', '', '', '', '', ''),
('', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `wedding`
--

DROP TABLE IF EXISTS `wedding`;
CREATE TABLE IF NOT EXISTS `wedding` (
  `sname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pnumber` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `day` varchar(50) NOT NULL,
  `month` varchar(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `attendees` varchar(50) NOT NULL,
  `guestrooms` varchar(50) NOT NULL,
  `request` varchar(400) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wedding`
--

INSERT INTO `wedding` (`sname`, `fname`, `email`, `pnumber`, `address`, `country`, `day`, `month`, `year`, `attendees`, `guestrooms`, `request`) VALUES
('shashi', 'wijendra', 'shashi@gmail.com', '0234567897', 'shashi,hambantota', 'India', '3', 'May', '2021', '100', 'yes', 'ehnjn'),
('wijendra', 'sanduni', 'shashi@gmail.com', '0774567765', 'sddn', 'Sri Lanka', '5', 'June', '2022', '100', 'no', 'No'),
('', '', '', '', '', 'Sri Lanka', '<<Day>>', '<<Month>>', '<<Year>>', '', 'null', ''),
('', '', '', '', '', 'Sri Lanka', '<<Day>>', '<<Month>>', '<<Year>>', '', 'null', ''),
('', '', '', '', '', 'Sri Lanka', '<<Day>>', '<<Month>>', '<<Year>>', '', 'null', ''),
('', '', '', '', '', 'Sri Lanka', '<<Day>>', '<<Month>>', '<<Year>>', '', 'null', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
